#[Sea Life Centre](https://www2.visitsealife.com/)

### Paul the Octopus key stats:
* **Hatched: January 26, 2008**
* **[Best Known for: Predicting results of 2010 World Cup Matches](http://www.ibtimes.com/octopus-made-better-world-cup-predictions-goldman-sachs-photos-1613882)**

### Paul the Octopus current Halloween outfit: 
* **[Cowboy Hat](http://www.allensboots.com/0475admy-adults-resistol-added-money-0475admy.html)**
* **[Heart-Shaped Glasses](https://www.spencersonline.com/product/accessories/sunglasses/heart-and-flower-sunglasses/pc/2021/c/0/sc/2209/116719.uts?currentIndex=0&thumbnailIndex=18)**
